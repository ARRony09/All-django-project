import imp
from django.shortcuts import render
from matplotlib.style import context
from .models import Post
# Create your views here.
def blogHome(request):
    allposts=Post.objects.all()
    context={"allposts":allposts}
    return render(request,'blog/blogHome.html',context)

def blogDetails(request,slug):
    post=Post.objects.filter(slug=slug).first()
    print(post)
    context={'post':post}
    return render(request,'blog/blogDetails.html',context)