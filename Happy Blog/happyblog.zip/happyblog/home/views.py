import email
from django.shortcuts import redirect, render
from matplotlib.pyplot import title
from django.contrib.auth.models import User
from blog.models import Post
from .models import Contact,DisplayPost
from django.contrib import messages
from django.contrib.auth import authenticate, login,logout


# Create your views here.
def home(request):
    allposts=Post.objects.all()
    param={"allposts":allposts}
    return render(request,'home/home.html',param)


def about(request):
    return render(request,'home/about.html')


def contact(request):
    if request.method=="POST":
        name=request.POST['name']
        email=request.POST['email']
        desc=request.POST['desc']
        if len(name)<8 or len(email)<10 or len(desc)<5:
            messages.error(request,"Fill the form correctly")
        else:
            contact = Contact(name=name,email=email,desc=desc)
            contact.save()
            messages.success(request,"Your message has been successfully sent")
    return render(request,'home/contact.html')

def handlelogin(request):
    if request.method=="POST":
        #email=request.POST['email']
        username=request.POST['username']
        password=request.POST["password"]
        user=authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            messages.success(request,"Successfully login")
        else:
            messages.error(request,"email or password is incorrect. Try again")

    return render(request,'home/login.html')

def signup(request):
    if request.method=="POST":
        email=request.POST['email']
        username=request.POST['username']
        phone=request.POST['phone']
        pass1=request.POST['pass1']
        pass2=request.POST['pass2']

        if len(email)<6:
            messages.error(request,"email should be more than 10 latter")
            return render(request,'home/signup.html')
        if pass1 != pass2:
            messages.error(request,"Password doesn't match")
            return render(request,'home/signup.html')
        if not username.isalnum():
            messages.error(request,"email should be more than 10 latter")
            return render(request,'home/signup.html')

        myuser=User.objects.create_user(username,email,pass1)
        myuser.phone_number=phone
        myuser.save()
        messages.success(request,"your account has been successfully created")
    else:
        messages.warning(request,"Fill the form correctly")
    return render(request,'home/signup.html')

def blog(request):
    return render(request,'blog/blogHome.html')

def handlelogout(request):
    logout(request)
    messages.success(request,"Successfully logout")
    return redirect('home')

def search(request):
    query=request.GET['query']

    if len(query)>80:
        allposts=Post.objects.none()
    else:
        allpostsTitle=Post.objects.filter(title__icontains=query)
        allpostsContent=Post.objects.filter(content__icontains=query)
        allpostsAuthor=Post.objects.filter(author__icontains=query)
        allposts=allpostsTitle.union(allpostsContent,allpostsAuthor)
    if allposts.count() == 0:
        messages.warning(request,"No search result found")
    params = {"allposts":allposts,'query':query}
    return render(request,'home/search.html',params)
